/* =========================================================
 * 問題データ（キャラ・セリフ・画像パス・出題順）
 * ---------------------------------------------------------
 * ・ここだけ編集すれば、セリフ・画像・出題順を変更できます。
 * ・order の小さい順に出題されます（配列の並び順は関係ありません）。
 * ・label に「仮」が付いているものは仮データです。丸ごと差し替えてOK。
 *
 * 【画像】
 *   image       : 通常の立ち絵（全身・透過PNG推奨）
 *                 例 "assets/characters/c01_dracula.webp"
 *                 空文字 or ファイルが無い場合は「画像準備中」シルエットで進行します。
 *   expressions : 表情差分（後日追加用）。{ happy: "パス", sad: "パス", ... }
 *                 セリフ側で face: "happy" のように指定すると切り替わります。
 *                 未設定の表情は image が使われます。
 *
 * 【セリフの書き方】
 *   "文字列"                          → その人物のセリフ
 *   { who: "me", text: "..." }        → プレイヤー（あなた）のセリフ
 *   { who: "narr", text: "..." }      → ナレーション
 *   { text: "...", face: "happy" }    → 表情差分つきのセリフ
 *
 * 【選択肢】
 *   { id: "a", text: "表示文", reaction: "外したときの一言（任意）" }
 *   正解は answerId で選択肢の id を指定（表示順はシャッフルされます）。
 *
 * 【カットイン】 missCutin: "画像パス" を書くと、そのキャラで間違えたときに画像がドーンと出ます（任意）。
 *   successFlash: "文字" で成功時の大きな文字を変えられます（任意）。
 *   successNarr: "文" で成功時のナレーション、successIcons: [...] で舞うアイコンを変えられます（任意）。
 *   entranceFlash: "文字" で登場時にドーンと文字が出ます。選択肢に sulk: true で、外れたとき落ち込んで帰っていきます（任意）。
 *   選択肢の noMissEffects / missNarr / gameOverText で、外れたときの演出・ナレーション・ゲームオーバー文を個別に変えられます。セリフの act: "ko" で吹っ飛ばし。
 *   選択肢に requires: "キャラid" を付けると、そのキャラと一緒に帰れていたときだけ表示されます。
 *   finale: {...} を持つキャラは仮装クイズなしの特別キャラ（最後のDJポリス）。lines を流したあと特別エンディング。
 *     セリフの act: "reveal"（画像切替＋ドン）/ "blackout"（暗転）で演出を付けられます。
 *   選択肢に gameOver: true を付けると、選んだ瞬間に不気味演出→ゲームオーバー（6人目レナで使用）。
 *
 * 【difficulty】 "easy"（前半）/ "normal"（中盤）/ "hard"（後半）
 * ========================================================= */
window.CHARACTERS = [
  /* ---------- 前半：見て分かる定番 ---------- */
  {
    id: "c01_dracula",
    label: "ドラキュラ（確定・練習枠）",
    order: 1,
    difficulty: "easy",
    name: "マントのお姉さん",
    color: "#b3122e",
    image: "assets/characters/c01_dracula.webp",
    expressions: {},
    appearance:
      "黒と赤のマントに黒いドレス、コウモリの髪飾り。口元につけ牙。両手で広げたマントの裏地は深い赤で、縁までていねいに仕立ててある。",
    intro: [
      "（マントの裾をふわっと広げて）こんばんは、人間さん……なんてね！",
      "このマント、生地選びから全部自分で縫ったんだ。ねえ、私のコスプレ、何かわかる？",
    ],
    hint: "黒と赤のマントにつけ牙。夜に現れて血が大好きな、あの有名キャラ。本人がいちばん推しているのは「手作りのマント」。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "ドラキュラ（吸血鬼）" },
        { id: "b", text: "魔女", reaction: "魔女じゃないよ！ ほうき持ってないでしょ！" },
        { id: "c", text: "マジシャン", reaction: "マジシャンじゃないってば！ ハトは出ないよ！" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "ドラキュラですよね！" },
        { text: "正解〜！ つけ牙、ちゃんと見てくれたんだ", face: "happy" },
      ],
      wrongLines: ["……ざーんねん。また今度、当ててみてね？"],
    },
    compliment: {
      question: "どこを褒める？",
      choices: [
        { id: "a", text: "顔立ちがすごくきれいですね！", reaction: "ありがと……でも、そこじゃないんだよね〜" },
        { id: "b", text: "マントの裏地の赤と縫い目、すごく丁寧ですね！" },
        { id: "c", text: "つけ牙、本物みたいで迫力ありますね！", reaction: "牙は100円ショップなんだよね〜……" },
      ],
      answerId: "b",
      successLines: [
        { text: "わかる！？ 裏地の縫い目、3日かかったの！", face: "happy" },
        { text: "あなたとは話が合いそう。一緒に帰ろう！", face: "happy" },
      ],
      failLines: ["じゃ、またどこかの夜に！ バイバ〜イ"],
    },
  },
  {
    id: "c02_nurse",
    label: "ナース（確定）",
    order: 2,
    difficulty: "easy",
    name: "ピンク髪のお姉さん",
    color: "#ff8fb8",
    image: "assets/characters/c02_nurse.webp",
    expressions: {},
    appearance:
      "白とピンクのナース服に、ハートのナースキャップ。手にはハート柄のピンクのカルテ。耳にはハートのイヤリング、白い靴にもハートの飾り。",
    intro: [
      "（手をひらひら振って）はーい、次の方どうぞ〜♪",
      "今日のテーマは「ハート」なの。頭のてっぺんから足の先まで、こだわってるんだから！",
    ],
    hint: "白い制服にナースキャップ、手にはカルテ。病院で患者さんのお世話をするあの人。本人のこだわりは「頭から足先まで」のハート。帽子・耳・カルテ・靴をよく見て！",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "ナース（看護師）" },
        { id: "b", text: "メイド", reaction: "メイドじゃないよ〜！ 「おかえりなさいませ」は言わないもん" },
        { id: "c", text: "アイドル", reaction: "うれしいけどちがーう！ 歌って踊ったりしないよ〜" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "ナースさんですね！" },
        { text: "せいかーい！ はなまる、あげちゃう♪", face: "happy" },
      ],
      wrongLines: ["……ざんねん！ また来てね〜♪"],
    },
    compliment: {
      question: "どこを褒める？",
      choices: [
        { id: "a", text: "ナースキャップのハート、かわいいですね！", reaction: "キャップかわいいでしょ！ ……でも、一番はそこじゃないの" },
        { id: "b", text: "帽子から靴まで、ハートで全身そろえてるの、こだわりがすごいです！" },
        { id: "c", text: "笑顔にすごく癒やされます！", reaction: "えへへ、ありがと♪ ……でも、ちょっと違うかな〜" },
      ],
      answerId: "b",
      successLines: [
        { text: "気づいてくれた！？ イヤリングも、カルテも、靴まで全部ハートなの！", face: "happy" },
        { text: "診断結果：相性バッチリ♥ 一緒に帰ろう！", face: "happy" },
      ],
      failLines: ["はーい、お大事に〜♪ またね！"],
    },
  },
  {
    id: "c03_gojo",
    label: "五条悟（確定）",
    order: 3,
    difficulty: "easy",
    name: "銀髪のお姉さん",
    color: "#2b2d5c",
    image: "assets/characters/c03_gojo.webp",
    expressions: {},
    appearance:
      "白い髪に、おでこまでずらした黒い目隠し。高い襟の紺色の制服とパンツ、黒いブーツ。手にはスマホ、肩から小さなバッグ。",
    intro: [
      "（目隠しをくいっと上げて）やっほー。ハロウィンの渋谷って……なんかイヤな予感しない？",
      "ま、安心して。今夜の私、たぶん最強だから♪",
      "衣装より、しゃべり方とか余裕のある感じを研究してきたんだよね〜",
    ],
    hint: "ハロウィンの渋谷、「最強」、余裕たっぷりの先生。呪術の世界のあのキャラ。本人が力を入れたのは衣装より「なりきり」。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "五条悟（呪術廻戦）" },
        { id: "b", text: "はたけカカシ（NARUTO）", reaction: "ちがうちがう！ 本も読んでないし、雷も出ないよ〜" },
        { id: "c", text: "坂田銀時（銀魂）", reaction: "木刀は持ってないよ〜！ ちがいまーす" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "五条悟ですよね！" },
        { text: "正解〜♪ 見る目あるじゃん。……私の目は隠れてるけどね", face: "happy" },
      ],
      wrongLines: ["……ま、私の正体を見抜くには、まだ修行が足りないかな？"],
    },
    compliment: {
      question: "どこを褒める？",
      choices: [
        { id: "a", text: "目隠しの上げ方、完全に本人ですね！", reaction: "目隠し？ これ実は、前が見えなくて大変なのよ〜" },
        { id: "b", text: "その余裕たっぷりの「最強感」、なりきり方がすごいです！" },
        { id: "c", text: "白い髪、地毛みたいにきれいです！", reaction: "髪はウィッグなんだよね〜、ふふ" },
      ],
      answerId: "b",
      successLines: [
        { text: "でしょ〜？ 原作を読み込んで、余裕の出し方を研究したの♪", face: "happy" },
        { text: "よし、一緒に帰ろ。帰り道に甘いもの買ってこ！", face: "happy" },
      ],
      failLines: ["じゃ、私は甘いもの食べに行くから。またね〜"],
    },
  },

  /* ---------- 中盤：小物・セリフを観察 ---------- */
  {
    id: "c04_mira",
    label: "ミラ（確定）",
    order: 4,
    difficulty: "normal",
    name: "ツインテールのお姉さん",
    color: "#d6336c",
    image: "assets/characters/c04_mira.webp",
    expressions: {},
    appearance:
      "ピンクの長いツインテールにトゲの髪飾り。黒いクロップドTシャツに黄色いチェックのミニスカート、チョーカーと厚底ブーツ。手には大きな刃のついた長い矛。",
    intro: [
      "（髪を指でくるくるしながら）……なに？ サインならあとにしてくれる？",
      "今夜もひと仕事終えてきたとこ。歌って、踊って、狩って。",
      "ツアー明けでマジでクタクタ。……今すぐ、ふかふかの何かにダイブしたい",
    ],
    hint: "歌って踊って悪魔を狩る、3人組ガールズグループの一人。ピンクのロングヘアと長い矛（コッド）が目印。本人はツアー明けで、とにかく体を休めたいらしい……。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "ミラ（KPop Demon Hunters）" },
        { id: "b", text: "ルミ（KPop Demon Hunters）", reaction: "は？ 私はルミじゃない。……一緒にしないで" },
        { id: "c", text: "初音ミク", reaction: "ツインテールだけで決めないでくれる？ ネギも持ってないし" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "ケデハンのミラですよね！" },
        { text: "……へぇ、わかるんだ。やるじゃん", face: "happy" },
      ],
      wrongLines: ["……ま、いいけど。次はちゃんと覚えといて"],
    },
    compliment: {
      question: "ミラがいま一番ほしいものは？",
      choices: [
        { id: "a", text: "ソファー" },
        { id: "b", text: "腹筋", reaction: "私、バキバキに割れた腹筋は好きだけど……お兄さん、ブヨブヨじゃん" },
        { id: "c", text: "ファンからの手紙", reaction: "手紙はうれしいよ。……けど、今じゃない" },
      ],
      answerId: "a",
      successFlash: "ソファー！！", // 成功時の大きな文字（任意。未設定なら「意気投合！」）
      successLines: [
        { text: "（目がキラッと光る）……っ！", face: "happy" },
        { text: "ソファー！ ソファー！ ソファー！", face: "happy" },
        { text: "あんた最高。一緒に帰ろ。で、ソファーに直行ね", face: "happy" },
      ],
      failLines: ["……出直してきて。じゃあね"],
    },
  },
  {
    id: "c05_sealbook",
    label: "シール帳（確定）",
    order: 5,
    difficulty: "normal",
    name: "パステルのお姉さん",
    color: "#c79bf2",
    image: "assets/characters/c05_sealbook.webp",
    expressions: {},
    appearance:
      "ラベンダーとピンクの大きなバインダー型の衣装。ポケットにはハートや星、うさぎのぷっくりシールがぎっしり。腕と脚にも同じ柄。手にはシールのシート。",
    intro: [
      "（シールをぺりっとはがして）ハッピーハロウィン！ ……あ、これ？ 今日のシルパトの戦利品！",
      "朝から3軒まわって、やっと1シート買えたの〜。もう足パンパン！",
      "ねえねえ、そっちは何か持ってない？ 交換しよ？",
    ],
    hint: "いま大人の女子にも大流行中の、ぷっくりシールを集めて交換するアレ。本人は交換したくてうずうずしている。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "シール帳" },
        { id: "b", text: "プリ帳（プリクラ帳）", reaction: "プリも撮りたいけど〜、ちがうんだなぁ" },
        { id: "c", text: "絵本", reaction: "読み聞かせはしないよ〜！" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "シール帳ですよね！" },
        { text: "せいか〜い！ 中身もぜんぶ本物のシールだよ♪", face: "happy" },
      ],
      wrongLines: ["……ざんねん！ 平成女児の心、忘れちゃった？"],
    },
    compliment: {
      question: "何て声をかける？",
      choices: [
        { id: "a", text: "ハロウィン限定のシール持ってるよ。交換しない？" },
        { id: "b", text: "シールって、ちょっと子どもっぽくない？", reaction: "……は？ 平成女児をなめないでくれる？" },
        { id: "c", text: "そのシール帳、全部でいくらかかったの？", reaction: "……それ聞く？ プライスレスなんですけど" },
      ],
      answerId: "a",
      successFlash: "交換成立！",
      successIcons: ["⭐", "💖", "🍓", "🌙", "🐰"],
      successLines: [
        { text: "えっ、ハロウィン限定！？ 見せて見せて〜！", face: "happy" },
        { text: "交換成立〜！ ……ねえ、もっと見せてほしいから一緒に帰ろ！", face: "happy" },
      ],
      failLines: ["……じゃ、次のシルパト行ってくるね！ バイバ〜イ"],
    },
  },
  {
    id: "c05_jibanyan",
    label: "ジバニャン（確定）",
    order: 6,
    difficulty: "normal",
    name: "鈴のお姉さん",
    color: "#e8452c",
    image: "assets/characters/c05_jibanyan.webp",
    expressions: {},
    appearance:
      "赤いモコモコのネコ耳パーカーで、お腹は白、腰に黄色い腹巻き。首に青い首輪と金の鈴。先に青い火の玉がついた赤いしっぽが2本。手にはスマホ。",
    intro: [
      "（ぐっと拳をにぎって）ひゃくれつ肉球〜っ！ ……ニャンてね！",
      "今夜のオレっちは、トラックにだって負けない気がするニャン！",
      "それより聞いてニャン！ あさって、ついに“アレ”がホールに来るニャン……！ 待ちきれないニャン！",
    ],
    hint: "赤いネコの妖怪で、しっぽの先に青い火の玉、首に鈴。口ぐせは「〜ニャン」。本人は、あさってホールに来る“アレ”が楽しみでしかたないらしい。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "ジバニャン（妖怪ウォッチ）" },
        { id: "b", text: "猫又（ねこまた）", reaction: "ちがうニャン！ しっぽの数だけで決めないでほしいニャン！" },
        { id: "c", text: "ドラえもん", reaction: "オレっち、ネズミは平気ニャン！ ポケットもないニャン！" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "ジバニャンですよね！" },
        { text: "当たりニャン！ キミ、なかなかやるニャン！", face: "happy" },
      ],
      wrongLines: ["……ちがうニャン。オレっち、ちょっと傷ついたニャン"],
    },
    compliment: {
      question: "ジバニャンをどう誘う？",
      choices: [
        { id: "a", text: "妖怪ウォッチのパチンコ打ちに行かない？" },
        { id: "b", text: "チョコボー買いに行かない？", reaction: "チョコボーは大好きニャン……でも今日はもう10本食べたニャン" },
        { id: "c", text: "ニャーKBのライブ行かない？", reaction: "ニャーKBは……推しは一人でじっくり見たい派ニャン" },
      ],
      answerId: "a",
      successFlash: "フィーバーニャン！",
      successLines: [
        { text: "ニャ、ニャんと！？ それ、オレっちも打ちたかったやつニャン！", face: "happy" },
        { text: "決まりニャン！ 今夜は一緒に帰って、あさっては一緒にホールに並ぶニャン♪", face: "happy" },
      ],
      failLines: ["……気分じゃないニャン。またニャン〜"],
    },
  },
  {
    id: "c06_rena",
    label: "竜宮レナ（確定）",
    order: 7,
    difficulty: "normal",
    name: "ベレー帽のお姉さん",
    color: "#f07a2a",
    image: "assets/characters/c06_rena.webp",
    expressions: {},
    // 間違えたときに出すカットイン画像（任意）
    missCutin: "assets/cutin/c06_rena_cutin.jpg",
    appearance:
      "白いベレー帽に青いリボン、青いラインの入った白いセーラー襟のワンピース。手には大きなナタ。肩から茶色のポシェット。",
    intro: [
      "（ベレー帽をちょんと直して）はぅ〜、渋谷のハロウィン、かぁいいものがいっぱいだよぉ〜",
      "このナタ？ ……ふふ、よくできてるでしょ？",
      "かぁいいもの……ふわふわのぬいぐるみとか見つけたら、つい、お持ち帰りしたくなっちゃうんだよね☆",
    ],
    hint: "白いベレー帽とワンピースに、大きなナタ。口ぐせは「はぅ〜」と「かな？かな？」。かぁいいもの、特にぬいぐるみに目がない。……手に持っているものには、触れないほうがいいかも。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "竜宮レナ（ひぐらしのなく頃に）" },
        { id: "b", text: "園崎魅音（ひぐらしのなく頃に）", reaction: "……ちがうよ？ ちがうよね？" },
        { id: "c", text: "お肉屋さん", reaction: "お肉屋さんじゃないよ〜。……このナタはね、ふふふ" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "竜宮レナですよね！" },
        { text: "はぅ〜！ 正解だよぉ〜！ うれしいな、うれしいな☆", face: "happy" },
      ],
      wrongLines: ["……ねえ。どうして、わかってくれないのかな？ かな？"],
    },
    compliment: {
      question: "レナに何て声をかける？",
      choices: [
        {
          id: "a",
          text: "そのナタ、本物みたいにリアルですね！",
          // gameOver: true を付けた選択肢を選ぶと、その場でゲームオーバー
          gameOver: true,
          reaction: [
            "…………",
            "ふふ……これ、本物だよー",
            "ねえ……キミも、すっごくかぁいいね。かぁいいね。",
            "……お持ち帰り〜☆",
          ],
          gameOverText: "あなたは、レナにお持ち帰りされてしまった……",
        },
        { id: "b", text: "かわいいぬいぐるみ、プレゼントさせて！" },
        { id: "c", text: "ベレー帽、とっても似合ってますね！", reaction: "……あはは。ちょっとびっくりさせちゃったかな、かな？" },
      ],
      answerId: "b",
      successFlash: "かぁいい〜☆",
      successLines: [
        { text: "はぅ〜！ ぬいぐるみ！？ かぁいい、かぁいいよぉ〜！", face: "happy" },
        { text: "一緒に帰ろうね！ ……ナタは、ちゃんとしまっておくから☆", face: "happy" },
      ],
      failLines: ["……またね。次は、嘘つかないでね？"],
    },
  },
  {
    id: "c07_tsukigesho",
    label: "月化粧（確定）",
    order: 8,
    difficulty: "normal",
    name: "まんまる頭のお姉さん",
    color: "#d9a441",
    image: "assets/characters/c07_tsukigesho.webp",
    thumbFocus: 0.22, // 結果画面のサムネイルで顔が見える位置
    expressions: {},
    appearance:
      "まんまるで黄色っぽい大きな被り物から、顔だけ出している。黒いスーツに黒いネクタイ、胸に白いポケットチーフ。手にはひと口かじった丸いお菓子。",
    // 登場セリフは答えのヒントなし（関西弁だけが手がかり）
    intro: [
      "（頭をよいしょと支えて）なあなあ、ちょっと聞いてや！",
      "この頭な、ほんま重たいねん。首もげそうやわ〜",
      "せやけど今日はこれでいくって決めてん。……で、うち何に見える？",
    ],
    hint: "関西弁でしゃべる、まんまるの被り物の人。大阪の人ならピンとくるはず。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "月化粧（みるく饅頭）" },
        { id: "b", text: "通りもん", reaction: "ちゃうねん！ それはそれで美味しいけどな！" },
        { id: "c", text: "満月", reaction: "空に浮いてへんやろ！ うち、地面に立ってるで！" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "月化粧ですよね！" },
        { text: "当たりや〜！ さすが、わかってるやん！", face: "happy" },
        { text: "被り物はな、ウケてナンボやで！", face: "happy" },
      ],
      wrongLines: ["……もうええわ。ほな、さいなら〜"],
    },
    compliment: {
      question: "どこを褒める？",
      choices: [
        { id: "a", text: "めっちゃかわいいです！", reaction: "かわいい？ ……うれしいけど、そういうことちゃうねん" },
        { id: "b", text: "めっちゃおもろいです！" },
        { id: "c", text: "めっちゃ上品です！", reaction: "上品？ この頭で！？" },
      ],
      answerId: "b",
      successFlash: "おおきに〜！",
      successLines: [
        { text: "せやろ〜！ 「おもろい」がいっちゃんうれしいわ！", face: "happy" },
        { text: "よっしゃ、一緒に帰ろ！ 手土産もあるで〜", face: "happy" },
      ],
      failLines: ["ほな、またな〜"],
    },
  },

  /* ---------- 後半：ひとひねり（ニュース・流行枠） ----------
   * ※後半3人は、正式版でニュース・流行の題材に差し替える想定の仮データです。
   *   現在はことわざ・あるあるを組み合わせた仮問題にしています。
   * --------------------------------------------------------- */
  {
    id: "c08_hori",
    label: "堀大輔（確定）",
    order: 9,
    difficulty: "hard",
    name: "ムキムキのお姉さん",
    color: "#5b6270",
    image: "assets/characters/c08_hori.webp",
    // 表情差分：face: "shy" のセリフで照れ顔に切り替わる
    expressions: { shy: "assets/characters/c08_hori_shy.webp" },
    appearance:
      "短い黒髪に、迷彩柄のタンクトップと黒いランニングパンツ。腕も脚もバキバキの筋肉。腕を組んで自信満々の笑顔。",
    intro: [
      "（腕を組んで）おつかれさまです！ ……あ、ボク、昨日も30分しか寝てないんで！",
      "寝る時間ってもったいなくないですか？ 起きてる時間ぜんぶ使って、筋トレしてます！",
      "ふぁ……いや、今のはあくびじゃないです。深呼吸です。ボク、眠くならない体なんで！",
    ],
    hint: "とにかく「寝てない」をアピールしまくる、筋肉自慢の人。いま話題の、あの短時間睡眠の人。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "堀大輔（ショートスリーパー）" },
        { id: "b", text: "ボディビルダー", reaction: "筋肉は自慢ですけど……ちがいます！" },
        { id: "c", text: "HRDISK", reaction: ["ちょっ……その呼び方はネットの中だけにしてください！", "ここは渋谷です。ちゃんと正式名称で呼んでください！"] },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "堀大輔さんですよね！" },
        { text: "正解です！ 睡眠は、鍛えられるんですよ！", face: "happy" },
        { text: "ちなみに今夜も朝まで起きてる予定です！ ……（目がしょぼしょぼ）", face: "happy" },
      ],
      wrongLines: ["……まあ、寝不足だと見間違えることもありますよね。ボクはないですけど"],
    },
    compliment: {
      question: "何て声をかける？",
      choices: [
        { id: "a", text: "もう無理しなくていいんだよ" },
        { id: "b", text: "さすが！ まだまだ起きてられますよね！", reaction: "……え、ええ、もちろん。……もちろんです……" },
        { id: "c", text: "一緒に朝まで筋トレしよう！", reaction: "朝まで……はい……（白目）" },
      ],
      answerId: "a",
      successFlash: "寝落ち…Zzz",
      successIcons: ["💤", "💕", "💤", "💗"],
      successLines: [
        { text: "……え", face: "shy" },
        { text: "……ありがとう。本当は、すごく眠くて……", face: "shy" },
        { text: "（すぅ……すぅ……）", face: "shy" },
      ],
      // 成功時のナレーション（任意。未設定なら「〇〇と一緒に帰ることになった！」）
      successNarr: "♥ 寝落ちしたムキムキのお姉さんを、お持ち帰りすることになった！（重い）",
      failLines: ["ボクは平気なんで！ じゃ、ジム行ってきます！"],
    },
  },
  {
    id: "c09_babaa",
    label: "デカいババア（確定）",
    order: 10,
    difficulty: "hard",
    name: "エプロンのおばあちゃん",
    color: "#3c4a6b",
    image: "assets/characters/c09_babaa.webp",
    // 表情差分：face: "shy" のセリフで照れ顔に切り替わる
    expressions: { shy: "assets/characters/c09_babaa_shy.webp" },
    // 登場時にドーンと出る文字（任意）
    entranceFlash: "ババァ〜ン！",
    appearance:
      "白髪のおだんご頭に丸メガネ。紺のシャツとロングスカートに、大きなエプロン。腕も肩も、異様にたくましい。",
    intro: [
      "どうなされた旅のお人。水でも飲むかい？",
      "（ニタァ……）遠慮はいらないよ。さあさあ、こっちへおいで",
      "なぁに、わしはただの、か弱いババアじゃよ……",
    ],
    hint: "やたらとたくましい、エプロン姿のおばあさん。世紀末の荒野で旅人に水をすすめてくる、あのマンガのあの人。",
    cosplay: {
      question: "この人のコスプレは何？",
      choices: [
        { id: "a", text: "デカいババア（北斗の拳）" },
        { id: "b", text: "ラオウ（北斗の拳）", reaction: "わしがあんな大男に見えるかい？ ……失礼じゃのう" },
        { id: "c", text: "ドーラ（天空の城ラピュタ）", reaction: "海賊じゃないよ！ 飛行船も持っとらんわい！" },
      ],
      answerId: "a",
      correctLines: [
        { who: "me", text: "北斗の拳のデカいババアですよね！" },
        { text: "ほっほっほ、よう知っとるのう。若いのに感心じゃ", face: "happy" },
      ],
      wrongLines: ["……ほっほっほ。そうかい、そうかい（目が笑ってない）"],
    },
    compliment: {
      question: "何て声をかける？",
      choices: [
        {
          id: "a",
          text: "お前のようなババアがいるか！",
          // 選ぶと「ホアチャア！」でおばあちゃんを倒してしまい、ゲームオーバー
          noMissEffects: true,
          reaction: [
            { who: "me", text: "お前のようなババアがいるか！" },
            { who: "me", text: "ホアチャア！", act: "boom", flashText: "ホアチャア！" },
            { who: "narr", text: "ドゴォッ！！", act: "ko" },
          ],
          missNarr: "エプロンのおばあちゃんは、渋谷の夜空へ吹っ飛んでいった……",
          gameOverText: "おばあちゃんを倒してしまった……\nもう一度、1人目からやり直し！",
        },
        { id: "b", text: "お水、いただきます！ やさしいおばあちゃんですね" },
        { id: "c", text: "腕、めちゃくちゃたくましいですね！", reaction: "腕？ ……そんなとこばっかり見とったのかい" },
      ],
      answerId: "b",
      successFlash: "ほっほっほ♥",
      successLines: [
        { text: "まあ……「やさしいおばあちゃん」なんて、何十年ぶりに言われたかねぇ", face: "shy" },
        { text: "よし、一緒に帰ろうかね。疲れたらおぶってやるよ", face: "shy" },
      ],
      successNarr: "♥ エプロンのおばあちゃんに、おぶわれて帰ることになった！",
      failLines: [],
    },
  },
  {
    id: "c11_djpolice",
    label: "DJポリス（特別エンディング）",
    order: 11,
    difficulty: "finale",
    name: "DJポリス",
    color: "#1f2f5c",
    image: "assets/characters/c11_djpolice.webp",
    // player: 主人公（あなた）の正体が明かされる場面で表示する画像
    expressions: { player: "assets/characters/player_apron.webp" },
    entranceFlash: "ピピーッ！",
    // 帰り道のナレーション。{together} が一緒に帰る人数に置き換わります（0人のときは introNarrZero）
    introNarr: "― 帰り道 ―\n{together}人と一緒に、ウキウキで渋谷の交差点を渡っていると……",
    introNarrZero: "― 帰り道 ―\nひとり、トボトボと渋谷の交差点を渡っていると……",
    appearance: "紺の制服に制帽、白い手袋。マイクを口元に構え、腰には拡声器。",
    intro: [],
    // finale: クイズなしの特別キャラ。lines を流したあと、特別エンディングへ
    finale: {
      lines: [
        "ちょっと君、怪しいね。ちょっとお話聞かせてくれるかな。",
        { who: "me", text: "ハロウィンコスプレ楽しんでるだけですけど！！" },
        "なんだその気持ち悪いコスプレは！",
        { who: "me", text: "え？" },
        {
          who: "narr",
          text: "……ショーウィンドウに映っていたのは、ピンクのエプロン姿の、ガタイのいい男だった。",
          face: "player",
          act: "reveal",
          flashText: "！？",
        },
        "君は怪しすぎる！ 今すぐ来なさい……！",
        { who: "narr", text: "こうして二人は、渋谷の闇に消えていった……", act: "blackout" },
      ],
      endingTitle: "ファーーーッ！！",
      endingText: "（取り調べは朝まで続いた…）",
    },
    hint: "",
    cosplay: { question: "", choices: [], answerId: "" },
    compliment: { question: "", choices: [], answerId: "" },
  },
];
