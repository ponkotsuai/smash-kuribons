/* =========================================================
 * ゲーム設定（公開URL・制作表記・シェア文など）
 * ここを書き換えるだけで反映されます。ゲーム処理の変更は不要です。
 * ========================================================= */
window.GAME_CONFIG = {
  // ゲームタイトル（画面表示用）
  title: "ハロウィン お持ち帰り大作戦",
  subtitle: "ハロウィンの夜の渋谷で、10人に声をかけよう",

  // 背景画像（渋谷の夜の街）。差し替えたい場合はパスを変更。空ならCSSの夜空グラデーション
  backgroundImage: "assets/bg/shibuya_night.jpg",
  // タイトル画面に立たせるキャラ画像（空なら表示しない）
  titleImage: "assets/characters/c01_dracula.webp",
  // 文字送りの速さ（1文字あたりのミリ秒。0で一瞬表示）
  textSpeed: 32,

  // 公開URL（未確定なら空のまま）。設定するとXシェア・コピー文に付きます
  publicUrl: "https://sono-cosplay.pages.dev",

  // 制作表記
  studioName: "OTK STUDIO",
  // 制作相談リンク（空ならリンク非表示）
  consultUrl: "",
  consultLabel: "ゲーム制作のご相談はこちら",

  // シェア文。{together} {cosplayCorrect} {total}(人数) {quiz}(クイズのある人数) が置き換わります
  shareText:
    "ハロウィンで{quiz}人に声をかけた結果…{together}人と一緒に帰れました！ 仮装当て：{cosplayCorrect}/{quiz}問 #ハロウィンお持ち帰り大作戦",

  // ゲームオーバー時のシェア文。{n} {together} {cosplayCorrect} {total}(人数) {quiz}(クイズのある人数) が置き換わります
  shareTextGameOver:
    "ハロウィンの渋谷で声をかけていったら…{n}人目でお持ち帰りされてゲームオーバー！ 一緒に帰れたのは{together}人でした #ハロウィンお持ち帰り大作戦",
  gameOverRank: "お持ち帰りされた人",
  // 最後にDJポリスに連行されたときのシェア文。{together} {cosplayCorrect} {total}(人数) {quiz}(クイズのある人数) が置き換わります
  shareTextAbduct:
    "ハロウィンの渋谷で{quiz}人に声をかけた結果…{together}人と一緒に帰れるはずが、帰り道でDJポリスに連行されました 仮装当て：{cosplayCorrect}/{quiz}問 #ハロウィンお持ち帰り大作戦",

  // スコア設定
  score: {
    cosplayCorrect: 100, // 仮装正解
    cosplayCorrectWithHint: 70, // ヒント使用時の仮装正解
    complimentSuccess: 100, // 褒め言葉成功
  },

  // 称号（獲得人数 min 以上で該当。上から順に判定）
  ranks: [
    { min: 10, title: "ハロウィンの伝説" },
    { min: 9, title: "あと一歩の伝説" },
    { min: 6, title: "仮装を見抜く達人" },
    { min: 3, title: "ハロウィンの人気者" },
    { min: 0, title: "声かけ練習中" },
  ],

  // 1人でも間違えたらゲームオーバー（1人目からやり直し）。false にすると間違えても10人全員に挑戦できる
  missIsGameOver: true,
  // 間違えてゲームオーバーになったときの文。{name} がキャラ名に置き換わります
  missGameOverText: "{name}にフラれてしまった……\nもう一度、1人目からやり直し！",
  // 間違えてゲームオーバーになったときのシェア文
  shareTextMiss:
    "ハロウィンの渋谷で声をかけていったら…{n}人目でフラれてゲームオーバー！ 一緒に帰れたのは{together}人でした #ハロウィンお持ち帰り大作戦",

  // ヒントボタンを使うか（false＝ヒントなし）
  enableHint: false,

  // 不正解のとき正解を見せるか（false＝見せない。結果画面でも外した仮装は「？？？」）
  revealAnswerOnMiss: false,

  // 選択肢を表示時にシャッフルする
  shuffleChoices: true,

  // 自己ベスト保存用キー（localStorage）
  storageKey: "otk_sonocosplay_v1",
};
