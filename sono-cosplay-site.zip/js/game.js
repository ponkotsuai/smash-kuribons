/* =========================================================
 * ゲーム処理（ギャルゲー風UI）
 * セリフ・画像・出題順の変更は js/data.js、設定は js/config.js で行います。
 * このファイルは通常編集不要です。
 * ========================================================= */
(function () {
  "use strict";

  /* ---------- 設定・データ ---------- */
  const CFG = Object.assign(
    {
      title: "ハロウィン お持ち帰り大作戦",
      subtitle: "",
      backgroundImage: "",
      titleImage: "",
      textSpeed: 32,
      publicUrl: "",
      studioName: "OTK STUDIO",
      consultUrl: "",
      consultLabel: "ゲーム制作のご相談はこちら",
      shareText: "{together}人と一緒に帰れました！",
      score: { cosplayCorrect: 100, cosplayCorrectWithHint: 70, complimentSuccess: 100 },
      ranks: [{ min: 0, title: "声かけ練習中" }],
      revealAnswerOnMiss: false,
      enableHint: true,
      missIsGameOver: true,
      missGameOverText: "{name}にフラれてしまった……",
      shareTextMiss: "{n}人目でフラれてゲームオーバー！",
      shareTextGameOver: "{n}人目でお持ち帰りされてゲームオーバー！",
      gameOverRank: "お持ち帰りされた人",
      shareTextAbduct: "{together}人と帰れるはずが、先輩に連れ去られました",
      shuffleChoices: true,
      storageKey: "otk_sonocosplay_v1",
    },
    window.GAME_CONFIG || {}
  );
  const DATA = (window.CHARACTERS || []).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  const TOTAL = DATA.length;
  const QUIZ = DATA.filter((c) => !c.finale).length; // 仮装クイズがある人数（先輩は除く）
  const DIFF_LABEL = { easy: "前半｜定番", normal: "中盤｜観察", hard: "後半｜ひとひねり", finale: "帰り道" };
  const KEYS = ["A", "B", "C", "D", "E"];

  const $ = (id) => document.getElementById(id);
  const el = {
    screens: document.querySelectorAll(".screen"),
    game: $("screen-game"),
    bgImg: $("bg-img"),
    bgTint: $("bg-tint"),
    screenFlash: $("screen-flash"),
    hudProgress: $("hud-progress"),
    hudScore: $("hud-score"),
    hudTogether: $("hud-together"),
    diffBadge: $("diff-badge"),
    charWrap: $("char-wrap"),
    img: $("char-img"),
    ph: $("char-placeholder"),
    appearance: $("char-appearance"),
    fx: $("fx-layer"),
    flash: $("result-flash"),
    msg: $("msg-window"),
    namePlate: $("name-plate"),
    speaker: $("speaker"),
    affection: $("affection"),
    affFill: $("aff-fill"),
    dialog: $("dialog"),
    line: $("line"),
    nextMark: $("next-mark"),
    hintNote: $("hint-note"),
    hintText: $("hint-text"),
    question: $("question"),
    qText: $("q-text"),
    choices: $("choices"),
    btnHint: $("btn-hint"),
    btnHide: $("btn-hide-ui"),
    uiRestore: $("ui-restore"),
    btnNext: $("btn-next"),
    cutin: $("cutin"),
    gameover: $("gameover"),
    gameoverText: $("gameover-text"),
    gameoverTitle: $("gameover-title"),
    cutinImg: $("cutin-img"),
  };

  /* ---------- 端末内保存（使えない環境でも続行） ---------- */
  const store = {
    get() {
      try {
        const s = window.localStorage.getItem(CFG.storageKey);
        return s ? JSON.parse(s) || {} : {};
      } catch (e) {
        return {};
      }
    },
    set(patch) {
      try {
        const cur = store.get();
        window.localStorage.setItem(CFG.storageKey, JSON.stringify(Object.assign(cur, patch)));
        return true;
      } catch (e) {
        return false;
      }
    },
  };

  /* ---------- 効果音（最初のユーザー操作後のみ再生） ---------- */
  const Sound = {
    enabled: true,
    ctx: null,
    init() {
      const s = store.get();
      if (typeof s.sound === "boolean") this.enabled = s.sound;
      this.renderToggles();
    },
    unlock() {
      try {
        if (!this.ctx) {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (AC) this.ctx = new AC();
        }
        if (this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      } catch (e) {
        this.ctx = null;
      }
    },
    toggle() {
      this.enabled = !this.enabled;
      store.set({ sound: this.enabled });
      this.renderToggles();
      if (this.enabled) this.play("tap");
    },
    renderToggles() {
      $("btn-sound-title").firstElementChild.textContent = this.enabled ? "効果音：ON" : "効果音：OFF";
      $("btn-sound-title").setAttribute("aria-pressed", String(this.enabled));
      $("btn-sound-game").textContent = this.enabled ? "🔊" : "🔇";
    },
    tone(freq, start, dur, type, vol) {
      const c = this.ctx;
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = type || "sine";
      o.frequency.value = freq;
      const t0 = c.currentTime + start;
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.12, t0 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g).connect(c.destination);
      o.start(t0);
      o.stop(t0 + dur + 0.02);
    },
    play(name) {
      if (!this.enabled || !this.ctx || this.ctx.state !== "running") return;
      try {
        switch (name) {
          case "tap":
            this.tone(1046, 0, 0.05, "sine", 0.05);
            break;
          case "type":
            this.tone(1400 + Math.random() * 200, 0, 0.02, "square", 0.012);
            break;
          case "select":
            this.tone(660, 0, 0.08, "triangle", 0.07);
            break;
          case "correct":
            [523, 659, 784, 1047].forEach((f, i) => this.tone(f, i * 0.08, 0.22, "triangle", 0.12));
            break;
          case "wrong":
            this.tone(240, 0, 0.18, "sawtooth", 0.07);
            this.tone(180, 0.16, 0.3, "sawtooth", 0.07);
            break;
          case "love":
            [784, 988, 1175, 1568, 1319, 1568].forEach((f, i) => this.tone(f, i * 0.09, 0.28, "sine", 0.1));
            break;
          case "hint":
            this.tone(1200, 0, 0.12, "sine", 0.08);
            this.tone(1600, 0.08, 0.18, "sine", 0.06);
            break;
          case "eerie":
            this.tone(55, 0, 0.25, "sine", 0.25);
            this.tone(52, 0.32, 0.3, "sine", 0.22);
            this.tone(55, 1.2, 0.25, "sine", 0.25);
            this.tone(52, 1.52, 0.3, "sine", 0.22);
            this.tone(1760, 0.1, 2.2, "sine", 0.015);
            break;
          case "gameover":
            [220, 207, 196, 147].forEach((f, i) => this.tone(f, i * 0.35, 0.6, "triangle", 0.1));
            break;
          case "boom":
            this.tone(70, 0, 0.6, "sawtooth", 0.2);
            this.tone(110, 0, 0.35, "square", 0.1);
            this.tone(46, 0.05, 0.7, "sine", 0.25);
            break;
          case "sulk":
            [392, 349, 311, 262].forEach((f, i) => this.tone(f, i * 0.28, 0.4, "triangle", 0.07));
            break;
          case "cutin":
            this.tone(90, 0, 0.5, "sawtooth", 0.18);
            this.tone(60, 0.02, 0.6, "square", 0.12);
            this.tone(1800, 0, 0.12, "square", 0.05);
            break;
          case "result":
            [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, i * 0.11, 0.3, "triangle", 0.1));
            break;
        }
      } catch (e) {
        /* 音が鳴らなくてもゲームは続行 */
      }
    },
  };

  /* ---------- 画像（未設定・読込失敗でもシルエットで続行） ---------- */
  const imgOk = new Set();
  const imgFailed = new Set();

  function preloadImages() {
    const paths = new Set();
    DATA.forEach((c) => {
      if (c.image) paths.add(c.image);
      if (c.missCutin) paths.add(c.missCutin);
      Object.values(c.expressions || {}).forEach((p) => p && paths.add(p));
    });
    paths.forEach((src) => {
      const im = new Image();
      im.onload = () => imgOk.add(src);
      im.onerror = () => imgFailed.add(src);
      im.src = src;
    });
  }

  function setupBackground() {
    if (!CFG.backgroundImage) return;
    const im = new Image();
    im.onload = () => {
      el.bgImg.style.backgroundImage = `url("${CFG.backgroundImage}")`;
    };
    im.src = CFG.backgroundImage; // 失敗時はCSSのグラデーションのまま
  }

  function setupTitleImage() {
    const t = $("title-char");
    if (!CFG.titleImage) return;
    t.onload = () => (t.hidden = false);
    t.onerror = () => (t.hidden = true);
    t.src = CFG.titleImage;
  }

  function showPlaceholder() {
    el.img.hidden = true;
    el.img.removeAttribute("data-src");
    el.ph.hidden = false;
  }

  function setCharImage(char, face) {
    const faceSrc = face && char.expressions ? char.expressions[face] : "";
    const src = (faceSrc && !imgFailed.has(faceSrc) ? faceSrc : "") || char.image || "";
    if (!src || imgFailed.has(src)) {
      showPlaceholder();
      return;
    }
    if (el.img.dataset.src === src && !el.img.hidden) return;
    el.img.dataset.src = src;
    el.img.onload = () => {
      if (el.img.dataset.src !== src) return;
      imgOk.add(src);
      el.img.hidden = false;
      el.ph.hidden = true;
    };
    el.img.onerror = () => {
      imgFailed.add(src);
      if (el.img.dataset.src !== src) return;
      if (src !== char.image && char.image && !imgFailed.has(char.image)) setCharImage(char);
      else showPlaceholder();
    };
    el.img.alt = char.name || "";
    el.img.src = src;
  }

  /* ---------- 状態 ---------- */
  let S = null;
  let token = 0; // リトライ時に古いタイマーを無効化

  function resetState() {
    token++;
    stopTyping();
    S = {
      idx: 0,
      score: 0,
      together: 0,
      cosplayCorrect: 0,
      hintCount: 0,
      records: [],
      phase: "idle", // talk / cosplay / compliment / resolving / next / transition / done / gameover
      cur: null,
      gameOver: false,
      abducted: false,
    };
    clearEerie();
    Dlg.queue = [];
    Dlg.done = null;
    Dlg.active = false;
    setUiHidden(false);
    el.bgTint.className = "bg-tint";
  }

  function later(fn, ms) {
    const t = token;
    setTimeout(() => {
      if (t === token) fn();
    }, ms);
  }

  /* ---------- 画面切替 ---------- */
  function showScreen(id) {
    el.screens.forEach((s) => s.classList.toggle("active", s.id === id));
    document.body.classList.toggle("on-title", id === "screen-title");
    window.scrollTo(0, 0);
  }

  /* ---------- HUD ---------- */
  function retrigger(node, cls) {
    node.classList.remove(cls);
    void node.offsetWidth;
    node.classList.add(cls);
  }
  function updateHud(bumpScore, bumpTogether) {
    const cur = DATA[Math.min(S.idx, TOTAL - 1)];
    el.hudProgress.textContent = cur && cur.finale ? "？？" : `${Math.min(S.idx + 1, QUIZ)}/${QUIZ}`;
    el.hudScore.textContent = S.score.toLocaleString();
    el.hudTogether.textContent = `${S.together}人`;
    if (bumpScore) retrigger(el.hudScore, "bump");
    if (bumpTogether) retrigger(el.hudTogether, "bump");
  }
  function setAffection(pct) {
    el.affFill.style.width = pct + "%";
    el.affection.classList.toggle("max", pct >= 100);
  }

  /* ---------- 文字送り ---------- */
  const TW = { full: "", i: 0, timer: null, typing: false };

  function stopTyping() {
    if (TW.timer) clearInterval(TW.timer);
    TW.timer = null;
    TW.typing = false;
  }
  function startTyping(text) {
    stopTyping();
    TW.full = text;
    TW.i = 0;
    el.line.textContent = "";
    el.nextMark.classList.add("off");
    const speed = (Number(CFG.textSpeed) || 0) * (document.body.classList.contains("eerie") ? 3 : 1);
    if (speed <= 0 || !text) {
      finishTyping();
      return;
    }
    TW.typing = true;
    TW.timer = setInterval(() => {
      TW.i++;
      el.line.textContent = TW.full.slice(0, TW.i);
      if (TW.i % 3 === 0) Sound.play("type");
      if (TW.i >= TW.full.length) finishTyping();
    }, speed);
  }
  function finishTyping() {
    stopTyping();
    el.line.textContent = TW.full;
    el.nextMark.classList.toggle("off", !Dlg.active);
  }

  /* ---------- 会話 ---------- */
  const Dlg = { queue: [], done: null, active: false, lockUntil: 0 };

  function normLine(ln) {
    if (typeof ln === "string") return { who: "char", text: ln };
    return Object.assign({ who: "char" }, ln);
  }
  function toArr(v) {
    if (!v) return [];
    return Array.isArray(v) ? v : [v];
  }

  function playLines(lines, done) {
    Dlg.queue = toArr(lines).map(normLine);
    Dlg.done = done;
    Dlg.active = true;
    S.phase = "talk";
    el.game.classList.remove("asking");
    el.question.hidden = true;
    el.btnNext.hidden = true;
    el.btnHint.hidden = true;
    advance(true);
  }

  function advance(force) {
    if (!Dlg.active) return;
    const now = performance.now();
    if (!force && now < Dlg.lockUntil) return; // 連打で会話が飛ばないように
    if (!force && TW.typing) {
      finishTyping(); // 1回目のタップは文字を全部表示
      Dlg.lockUntil = now + 200;
      return;
    }
    if (Dlg.queue.length === 0) {
      Dlg.active = false;
      el.nextMark.classList.add("off");
      const d = Dlg.done;
      Dlg.done = null;
      if (!force) Sound.play("tap");
      if (d) d();
      return;
    }
    if (!force) Sound.play("tap");
    renderLine(Dlg.queue.shift());
    Dlg.lockUntil = now + 250;
  }

  function renderLine(ln) {
    const char = S.cur ? S.cur.char : null;
    el.msg.className = "msg-window";
    el.namePlate.className = "name-plate";
    if (ln.who === "me") {
      el.speaker.textContent = "あなた";
      el.namePlate.classList.add("me");
    } else if (ln.who === "narr") {
      el.speaker.textContent = "";
      el.namePlate.classList.add("empty");
      el.msg.classList.add("narr");
      if (ln.cls) el.msg.classList.add(ln.cls);
    } else {
      el.speaker.textContent = char ? char.name : "";
      if (char) setCharImage(char, ln.face);
    }
    if (ln.who !== "char" && ln.face && char) setCharImage(char, ln.face);
    if (ln.act === "reveal") {
      retrigger(el.screenFlash, "go");
      flash(ln.flashText || "！？", "boom");
      retrigger(el.game, "shake");
      Sound.play("boom");
    }
    if (ln.act === "blackout") {
      el.game.classList.add("blackout");
      Sound.play("sulk");
    }
    if (ln.act === "boom") {
      flash(ln.flashText || "ドーン！", "boom");
      retrigger(el.game, "shake");
      Sound.play("boom");
    }
    if (ln.act === "ko") {
      el.charWrap.classList.remove("enter", "glow", "joy", "hurt");
      el.charWrap.classList.add("ko");
      retrigger(el.screenFlash, "go");
      retrigger(el.game, "shake");
      Sound.play("cutin");
    }
    if (ln.act === "sulk") {
      el.charWrap.classList.remove("enter", "glow", "joy", "hurt");
      el.charWrap.classList.add("sulk");
      Sound.play("sulk");
    }
    startTyping(ln.text || "");
  }

  /* ---------- 演出 ---------- */
  function flash(text, kind) {
    el.flash.textContent = text;
    el.flash.className = "result-flash " + kind;
    void el.flash.offsetWidth;
    el.flash.classList.add("show");
  }
  function sparkles() {
    const r = el.charWrap.getBoundingClientRect();
    for (let i = 0; i < 18; i++) {
      const s = document.createElement("span");
      s.className = "sparkle";
      const a = (Math.PI * 2 * i) / 18;
      const d = 90 + Math.random() * 80;
      s.style.left = r.left + r.width / 2 + "px";
      s.style.top = r.top + r.height * 0.4 + "px";
      s.style.setProperty("--dx", Math.cos(a) * d + "px");
      s.style.setProperty("--dy", Math.sin(a) * d + "px");
      el.fx.appendChild(s);
      setTimeout(() => s.remove(), 1000);
    }
  }
  function hearts(customIcons) {
    const icons = customIcons && customIcons.length ? customIcons : ["💖", "💕", "💗", "❤️", "💘"];
    const r = el.charWrap.getBoundingClientRect();
    for (let i = 0; i < 16; i++) {
      const h = document.createElement("span");
      h.className = "heart";
      h.textContent = icons[i % icons.length];
      h.style.left = r.left + r.width * (0.1 + Math.random() * 0.8) + "px";
      h.style.animationDelay = Math.random() * 0.7 + "s";
      h.style.fontSize = 18 + Math.random() * 20 + "px";
      h.style.setProperty("--rot", Math.random() * 40 - 20 + "deg");
      el.fx.appendChild(h);
      setTimeout(() => h.remove(), 2900);
    }
  }
  function tint(kind) {
    el.bgTint.className = "bg-tint " + (kind || "");
  }

  /* ---------- 不正解カットイン ---------- */
  function showCutin(src, done) {
    if (!src || !imgOk.has(src)) {
      done();
      return;
    }
    const t0 = performance.now();
    let closed = false;
    el.cutinImg.src = src;
    el.cutin.hidden = false;
    el.cutin.classList.remove("out");
    retrigger(el.cutin, "in");
    retrigger(el.game, "shake");
    Sound.play("cutin");
    const close = () => {
      if (closed) return;
      closed = true;
      el.cutin.classList.add("out");
      later(() => {
        el.cutin.hidden = true;
        el.cutin.classList.remove("in", "out");
        done();
      }, 280);
    };
    el.cutin.onclick = () => {
      if (performance.now() - t0 > 600) close(); // 0.6秒以降はタップで閉じられる
    };
    later(close, 1900);
  }

  /* ---------- 立ち絵をじっくり見るモード ---------- */
  function setUiHidden(on) {
    el.game.classList.toggle("ui-hidden", !!on);
    el.uiRestore.hidden = !on;
  }

  /* ---------- ゲーム進行 ---------- */
  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  function choiceText(q, id) {
    const c = (q.choices || []).find((x) => x.id === id);
    return c ? c.text : "";
  }

  function startGame() {
    if (!TOTAL) {
      $("title-sub").textContent = "問題データがありません（js/data.js を確認してください）";
      return;
    }
    resetState();
    showScreen("screen-game");
    startPerson();
  }

  function startPerson() {
    const char = DATA[S.idx];
    S.cur = {
      char,
      hintUsed: false,
      answered: false,
      record: {
        id: char.id,
        name: char.name,
        color: char.color,
        image: char.image,
        thumbFocus: char.thumbFocus,
        answerText: char.finale ? "" : choiceText(char.cosplay, char.cosplay.answerId),
        finale: !!char.finale,
        cosplay: false,
        compliment: false,
        hint: false,
        score: 0,
      },
    };
    el.hintNote.hidden = true;
    el.hintText.textContent = "";
    el.question.hidden = true;
    el.btnNext.hidden = true;
    el.btnHint.hidden = true;
    el.fx.innerHTML = "";
    tint("");
    setAffection(0);
    el.game.style.setProperty("--char-color", char.color || "#8a4fd8");
    el.diffBadge.textContent = DIFF_LABEL[char.difficulty] || "";
    el.diffBadge.className = "diff-badge " + (char.difficulty || "");
    el.appearance.textContent = char.appearance || "";
    el.charWrap.classList.remove("leave", "sulk", "ko");
    showPlaceholder();
    setCharImage(char);
    retrigger(el.charWrap, "enter");
    updateHud();
    if (char.entranceFlash) {
      later(() => {
        flash(char.entranceFlash, "boom");
        retrigger(el.game, "shake");
        Sound.play("boom");
      }, 450);
    }

    let narr = char.introNarr || `― ${S.idx + 1}人目 ―\n${char.name}に声をかけた！`;
    if (S.together === 0 && char.introNarrZero) narr = char.introNarrZero;
    narr = narr.replace(/\{together\}/g, S.together);
    const lines = [{ who: "narr", text: narr }].concat(toArr(char.intro));
    if (char.finale && char.finale.lines) {
      // クイズなしのカットシーン → 特別エンディング
      playLines(lines.concat(toArr(char.finale.lines)), () => finishFinale());
      return;
    }
    playLines(lines, () => ask(char.finale ? "finale" : "cosplay"));
  }

  function ask(type) {
    const char = S.cur.char;
    const q = char[type];
    S.phase = type;
    S.cur.answered = false;
    el.qText.textContent = q.question || (type === "cosplay" ? "この人のコスプレは何？" : "どこを褒める？");
    el.choices.innerHTML = "";
    // requires: そのキャラと一緒に帰れていたときだけ出す選択肢
    const usable = q.choices.filter((c) => !c.requires || S.records.some((r) => r.id === c.requires && r.cosplay && r.compliment));
    const list = CFG.shuffleChoices ? shuffle(usable.slice()) : usable.slice();
    list.forEach((c, i) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "choice";
      b.dataset.id = c.id;
      const k = document.createElement("span");
      k.className = "key";
      k.textContent = KEYS[i] || String(i + 1);
      const t = document.createElement("span");
      t.textContent = c.text;
      b.append(k, t);
      b.addEventListener("click", () => choose(type, c, b));
      el.choices.appendChild(b);
    });
    el.btnHint.hidden = !(CFG.enableHint && type === "cosplay" && !!char.hint && !S.cur.hintUsed);
    el.btnHint.disabled = false;
    el.question.hidden = false;
    el.btnNext.hidden = true;
    el.game.classList.add("asking");
  }

  function choose(type, choice, btn) {
    if (S.phase !== type || S.cur.answered) return; // 二重回答防止
    S.cur.answered = true;
    S.phase = "resolving";
    Sound.play("select");
    const q = S.cur.char[type];
    const ok = choice.id === q.answerId;
    el.btnHint.hidden = true;
    if (type === "finale") {
      // 先輩：どれを選んでも連れ去られる
      el.choices.querySelectorAll(".choice").forEach((b) => (b.disabled = true));
      btn.classList.add("chosen");
      later(() => resolveFinale(choice), 700);
      return;
    }
    if (choice.gameOver) {
      // ゲームオーバー分岐：正解も✕も出さず、静かに不気味な空気へ
      el.choices.querySelectorAll(".choice").forEach((b) => (b.disabled = true));
      btn.classList.add("eerie");
      later(() => resolveGameOver(choice), 900);
      return;
    }
    el.choices.querySelectorAll(".choice").forEach((b) => {
      b.disabled = true;
      if (b.dataset.id === q.answerId && (ok || CFG.revealAnswerOnMiss)) b.classList.add("correct");
    });
    if (!ok) btn.classList.add("wrong");
    later(() => (type === "cosplay" ? resolveCosplay(ok, choice) : resolveCompliment(ok, choice)), 800);
  }

  function useHint() {
    if (!CFG.enableHint || S.phase !== "cosplay" || S.cur.answered || S.cur.hintUsed) return;
    S.cur.hintUsed = true;
    S.cur.record.hint = true;
    S.hintCount++;
    el.hintText.textContent = S.cur.char.hint;
    el.hintNote.hidden = false;
    el.btnHint.hidden = true;
    Sound.play("hint");
  }

  function resolveCosplay(ok, choice) {
    const char = S.cur.char;
    const q = char.cosplay;
    const rec = S.cur.record;
    if (ok) {
      const pts = S.cur.hintUsed ? CFG.score.cosplayCorrectWithHint : CFG.score.cosplayCorrect;
      S.score += pts;
      rec.score += pts;
      rec.cosplay = true;
      S.cosplayCorrect++;
      updateHud(true);
      setAffection(50);
      retrigger(el.screenFlash, "go");
      retrigger(el.charWrap, "glow");
      sparkles();
      flash("正解！", "ok");
      Sound.play("correct");
      const lines = [
        { who: "narr", text: `◯ 正解！ ＋${pts}点${S.cur.hintUsed ? "（ヒント使用）" : ""}`, cls: "ok" },
      ].concat(toArr(q.correctLines));
      playLines(lines, () => ask("compliment"));
    } else {
      const missText = CFG.revealAnswerOnMiss ? `✕ ハズレ！\n正解は「${choiceText(q, q.answerId)}」` : "✕ ハズレ！";
      const lines = [{ who: "narr", text: missText, cls: "ng" }]
        .concat(toArr(choice.reaction))
        .concat(toArr(q.wrongLines))
        .concat([{ who: "narr", text: `${char.name}とはここでお別れ…`, cls: "ng" }]);
      S.cur.missChoice = choice;
      missEffects(char, () => playLines(lines, () => afterMiss()));
    }
  }

  function resolveCompliment(ok, choice) {
    const char = S.cur.char;
    const q = char.compliment;
    const rec = S.cur.record;
    if (ok) {
      const pts = CFG.score.complimentSuccess;
      S.score += pts;
      rec.score += pts;
      rec.compliment = true;
      S.together++;
      updateHud(true, true);
      setAffection(100);
      tint("love");
      retrigger(el.charWrap, "joy");
      hearts(q.successIcons);
      flash(q.successFlash || "意気投合！", "love");
      Sound.play("love");
      const lines = toArr(q.successLines).concat([
        { who: "narr", text: `${q.successNarr || `♥ ${char.name}と一緒に帰ることになった！`} ＋${pts}点`, cls: "love" },
      ]);
      playLines(lines, () => endPerson());
    } else {
      const lines = toArr(choice.reaction)
        .concat(toArr(q.failLines))
        .concat([
          {
            who: "narr",
            text: choice.missNarr
              ? choice.missNarr
              : choice.sulk
              ? `${char.name}は、しょんぼりと帰っていった…`
              : CFG.revealAnswerOnMiss
              ? `${char.name}は帰っていった…\nこだわりは「${choiceText(q, q.answerId)}」でした`
              : `${char.name}は帰っていった…`,
            cls: "ng",
            act: choice.sulk ? "sulk" : undefined,
          },
        ]);
      S.cur.missChoice = choice;
      if (choice.noMissEffects) {
        tint("ng");
        playLines(lines, () => afterMiss());
      } else {
        missEffects(char, () => playLines(lines, () => afterMiss()), "おしい…");
      }
    }
  }

  /* ---------- ゲームオーバー ---------- */
  function clearEerie() {
    document.body.classList.remove("eerie");
    el.game.classList.remove("eerie", "blackout");
    el.gameover.hidden = true;
  }

  function resolveGameOver(choice) {
    const rec = S.cur.record;
    rec.gameOver = true;
    S.gameOver = true;
    document.body.classList.add("eerie");
    el.game.classList.add("eerie");
    tint("eerie");
    setAffection(0);
    Sound.play("eerie");
    playLines(toArr(choice.reaction), () => {
      S.records.push(rec);
      S.phase = "gameover";
      el.question.hidden = true;
      later(() => showGameOver(choice), 400);
    });
  }

  // 間違えたときの処理：missIsGameOver なら即ゲームオーバー（1人目からやり直し）
  function afterMiss() {
    if (!CFG.missIsGameOver) {
      endPerson();
      return;
    }
    const rec = S.cur.record;
    rec.gameOver = true;
    S.records.push(rec);
    S.gameOver = true;
    S.gameOverType = "miss";
    S.phase = "gameover";
    el.question.hidden = true;
    el.gameover.classList.remove("abduct");
    el.gameoverTitle.textContent = "GAME OVER";
    const mc = S.cur.missChoice;
    el.gameoverText.textContent = ((mc && mc.gameOverText) || CFG.missGameOverText || "{name}にフラれてしまった……").replace(/\{name\}/g, S.cur.char.name);
    later(() => {
      el.gameover.hidden = false;
      Sound.play("gameover");
    }, 500);
  }

  function showGameOver(choice) {
    S.gameOverType = "special";
    el.gameover.classList.remove("abduct");
    el.gameoverTitle.textContent = "GAME OVER";
    el.gameoverText.textContent = choice.gameOverText || `${S.cur.char.name}にお持ち帰りされてしまった……`;
    el.gameover.hidden = false;
    Sound.play("gameover");
  }

  /* ---------- 先輩エンディング（どれを選んでも連れ去られる） ---------- */
  function resolveFinale(choice) {
    const fin = S.cur.char.finale;
    const lines = toArr(choice.reaction).concat(toArr(fin.abductLines));
    playLines(lines, () => finishFinale());
  }

  function finishFinale() {
    const fin = S.cur.char.finale;
    S.abducted = true;
    S.cur.record.abductor = true;
    S.records.push(S.cur.record);
    S.phase = "gameover";
    el.question.hidden = true;
    el.gameover.classList.add("abduct");
    el.gameoverTitle.textContent = fin.endingTitle || "連れ去られた…";
    el.gameoverText.textContent = fin.endingText || "";
    later(() => {
      el.gameover.hidden = false;
      retrigger(el.game, "shake");
      Sound.play("boom");
    }, 600);
  }

  // 不正解の演出（カットイン画像があればカットイン、なければ揺れ＋文字）
  function missEffects(char, next, label) {
    tint("ng");
    retrigger(el.charWrap, "hurt");
    if (char.missCutin && imgOk.has(char.missCutin)) {
      showCutin(char.missCutin, next);
      return;
    }
    retrigger(el.game, "shake");
    flash(label || "ざんねん…", "ng");
    Sound.play("wrong");
    next();
  }

  function endPerson() {
    S.records.push(S.cur.record);
    S.phase = "next";
    el.question.hidden = true;
    el.btnNext.firstElementChild.textContent = S.idx + 1 >= TOTAL ? "結果を見る" : "次の人へ";
    el.btnNext.hidden = false;
    el.btnNext.disabled = false;
  }

  function goNext() {
    if (S.phase !== "next") return; // 連打防止
    S.phase = "transition";
    el.btnNext.disabled = true;
    Sound.play("tap");
    setUiHidden(false);
    el.charWrap.classList.add("leave");
    later(() => {
      S.idx++;
      if (S.idx < TOTAL) startPerson();
      else showResult();
    }, 320);
  }

  /* ---------- 結果 ---------- */
  function rankTitle(n) {
    const ranks = CFG.ranks.slice().sort((a, b) => b.min - a.min);
    const r = ranks.find((x) => n >= x.min);
    return r ? r.title : "";
  }

  function miniSilhouette(color) {
    return `<svg viewBox="0 0 200 520" aria-hidden="true"><g fill="${color || "#8a4fd8"}"><ellipse cx="100" cy="46" rx="30" ry="37"/><path d="M88 80h24v14H88z"/><path d="M60 96c10-6 70-6 80 0l12 120c-6 4-14 4-18 0l-6-60-4 90H68l-4-90-6 60c-4 4-12 4-18 0z"/><path d="M68 244h64l-4 260c-6 6-18 6-22 0l-6-200-6 200c-4 6-16 6-22 0z"/></g></svg>`;
  }

  function buildShareText() {
    const tpl = S.gameOver ? (S.gameOverType === "miss" ? CFG.shareTextMiss : CFG.shareTextGameOver) : S.abducted ? CFG.shareTextAbduct : CFG.shareText;
    return tpl
      .replace(/\{n\}/g, S.records.findIndex((r) => r.gameOver) + 1)
      .replace(/\{together\}/g, S.together)
      .replace(/\{cosplayCorrect\}/g, S.cosplayCorrect)
      .replace(/\{total\}/g, TOTAL)
      .replace(/\{quiz\}/g, QUIZ)
      .replace(/\{score\}/g, S.score);
  }

  function showResult() {
    S.phase = "done";
    tint("");
    clearEerie();
    $("res-kicker").textContent = S.gameOver ? "― GAME OVER ―" : S.abducted ? "― SPECIAL ENDING ―" : "― RESULT ―";
    const note = $("res-note");
    note.hidden = !S.abducted;
    if (S.abducted) note.textContent = `……本当は ${S.together}人 と帰れるはずだった`;
    // ゲームオーバー時は、たどり着けなかった人を「未到達」として並べる
    if (S.gameOver) {
      for (let i = S.records.length; i < TOTAL; i++) {
        const c = DATA[i];
        S.records.push({ id: c.id, name: "？？？", color: c.color, image: "", answerText: "", cosplay: false, compliment: false, hint: false, score: 0, unreached: true });
      }
    }
    $("res-together").textContent = S.abducted ? 0 : S.together;
    $("res-total").textContent = QUIZ;
    $("res-rank").textContent = "称号：" + (S.gameOver && S.gameOverType !== "miss" ? CFG.gameOverRank : rankTitle(S.together));
    $("res-score").textContent = S.score.toLocaleString() + "点";
    $("res-cosplay").textContent = `${S.cosplayCorrect}/${QUIZ}`;
    $("res-hint").textContent = `${S.hintCount}人`;

    // 自己ベスト（獲得人数→スコアの順で比較）
    const prev = store.get().best;
    let bestMsg = "";
    const isNew = !prev || S.together > prev.together || (S.together === prev.together && S.score > prev.score);
    if (isNew) {
      const saved = store.set({ best: { together: S.together, score: S.score } });
      if (saved) bestMsg = prev ? "🎉 自己ベスト更新！" : "🎃 はじめての記録を保存しました";
    } else {
      bestMsg = `自己ベスト：${prev.together}人／${Number(prev.score).toLocaleString()}点`;
    }
    $("res-best").textContent = bestMsg;

    const ul = $("res-list");
    ul.innerHTML = "";
    S.records.forEach((r, i) => {
      const li = document.createElement("li");
      const success = r.cosplay && r.compliment;
      if (success) li.className = "ok";
      if (r.gameOver) li.className = "gameover-row";
      if (r.unreached) li.className = "unreached";
      if (S.abducted && success) li.className = "leftbehind";
      if (r.abductor) li.className = "abductor";
      const thumb = document.createElement("div");
      thumb.className = "rl-thumb";
      if (success || r.abductor) {
        if (r.image && imgOk.has(r.image)) {
          const im = document.createElement("img");
          // サムネイルの顔位置（0〜1、上からの割合）。data.js の thumbFocus で調整
          const focus = typeof r.thumbFocus === "number" ? r.thumbFocus : 0.08;
          im.onload = () => {
            const h = 96 * (im.naturalHeight / (im.naturalWidth || 1)); // 幅96px（200%）で表示したときの高さ
            im.style.top = `${Math.min(0, -(focus * h) + 22)}px`;
          };
          im.src = r.image;
          im.alt = r.name;
          thumb.appendChild(im);
        } else thumb.innerHTML = miniSilhouette(r.color);
      } else {
        thumb.classList.add("miss");
        thumb.textContent = "？";
      }
      li.innerHTML = `<span class="rl-num">${i + 1}</span>`;
      li.appendChild(thumb);
      const body = document.createElement("div");
      body.className = "rl-body";
      const nm = document.createElement("div");
      nm.className = "rl-name";
      nm.textContent = r.name;
      const sub = document.createElement("div");
      sub.className = "rl-sub";
      const shown = r.cosplay || CFG.revealAnswerOnMiss ? r.answerText : "？？？";
      sub.textContent = r.abductor ? "帰り道に現れた" : r.unreached ? "たどり着けなかった……" : `仮装：${shown}${r.hint ? "　💡ヒント" : ""}　${r.score}点`;
      body.append(nm, sub);
      li.appendChild(body);
      const st = document.createElement("span");
      st.className = "rl-status";
      st.textContent = r.abductor ? "連行" : S.abducted && success ? "またね…" : r.unreached ? "未到達" : r.gameOver ? "GAME OVER" : success ? "♥ 成功" : r.cosplay ? "褒め失敗" : "仮装ハズレ";
      li.appendChild(st);
      ul.appendChild(li);
    });

    const text = buildShareText();
    let xUrl = "https://x.com/intent/post?text=" + encodeURIComponent(text);
    if (CFG.publicUrl) xUrl += "&url=" + encodeURIComponent(CFG.publicUrl);
    $("btn-share-x").href = xUrl;
    $("copy-msg").textContent = "";
    $("copy-fallback").hidden = true;

    showScreen("screen-result");
    Sound.play("result");
  }

  function copyResult() {
    const text = buildShareText() + (CFG.publicUrl ? "\n" + CFG.publicUrl : "");
    const msg = $("copy-msg");
    const fb = $("copy-fallback");
    const fallback = () => {
      fb.value = text;
      fb.hidden = false;
      fb.focus();
      fb.select();
      let ok = false;
      try {
        ok = document.execCommand("copy");
      } catch (e) {
        ok = false;
      }
      msg.textContent = ok ? "コピーしました！" : "下のテキストを長押し（選択）してコピーしてください";
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard
          .writeText(text)
          .then(() => {
            msg.textContent = "コピーしました！";
            fb.hidden = true;
          })
          .catch(fallback);
      } else fallback();
    } catch (e) {
      fallback();
    }
  }

  function showTitle() {
    token++;
    stopTyping();
    const best = store.get().best;
    const b = $("title-best");
    if (best) {
      b.textContent = `自己ベスト：${best.together}人／${Number(best.score).toLocaleString()}点`;
      b.hidden = false;
    } else b.hidden = true;
    tint("");
    clearEerie();
    showScreen("screen-title");
  }

  /* ---------- 初期化 ---------- */
  function init() {
    document.title = CFG.title;
    $("title-sub").textContent = CFG.subtitle || "";
    const penalty = CFG.score.cosplayCorrect - CFG.score.cosplayCorrectWithHint;
    $("hint-cost").textContent = penalty > 0 ? `-${penalty}点` : "";
    // ヒントを使わない設定のときは、説明文と結果画面の「ヒント使用」も隠す
    $("howto-hint").hidden = !CFG.enableHint;
    $("howto-hint-score").hidden = !CFG.enableHint;
    $("res-hint-box").hidden = !CFG.enableHint;

    document.querySelectorAll(".credit").forEach((f) => {
      f.querySelector(".credit-studio").textContent = CFG.studioName ? "制作：" + CFG.studioName : "";
      const a = f.querySelector(".credit-link");
      if (CFG.consultUrl) {
        a.href = CFG.consultUrl;
        a.textContent = CFG.consultLabel;
        a.hidden = false;
      } else a.hidden = true;
    });

    Sound.init();
    setupBackground();
    setupTitleImage();
    preloadImages();
    resetState();

    const unlock = () => Sound.unlock();
    document.addEventListener("pointerdown", unlock, { passive: true });
    document.addEventListener("keydown", unlock);

    $("btn-start").addEventListener("click", startGame);
    $("btn-howto").addEventListener("click", () => {
      Sound.play("tap");
      showScreen("screen-howto");
    });
    $("btn-howto-start").addEventListener("click", startGame);
    $("btn-howto-back").addEventListener("click", showTitle);
    $("btn-sound-title").addEventListener("click", () => Sound.toggle());
    $("btn-sound-game").addEventListener("click", () => Sound.toggle());

    el.dialog.addEventListener("click", () => advance(false));
    el.btnHint.addEventListener("click", useHint);
    el.btnNext.addEventListener("click", goNext);
    el.btnHide.addEventListener("click", () => {
      Sound.play("tap");
      setUiHidden(true);
    });
    el.uiRestore.addEventListener("click", () => setUiHidden(false));

    $("btn-retry").addEventListener("click", startGame);
    $("btn-go-retry").addEventListener("click", startGame);
    $("btn-go-result").addEventListener("click", () => {
      if (S.phase === "gameover") showResult();
    });
    $("btn-to-title").addEventListener("click", showTitle);
    $("btn-copy").addEventListener("click", copyResult);

    // PC向けキーボード操作：Enter/Space=会話送り・次へ、1〜3/A〜C=選択、H=ヒント、V=ウィンドウ切替
    document.addEventListener("keydown", (e) => {
      if (!el.game.classList.contains("active")) return;
      const k = e.key;
      if (el.game.classList.contains("ui-hidden")) {
        if (k === "v" || k === "V" || k === "Escape" || k === "Enter" || k === " ") {
          e.preventDefault();
          setUiHidden(false);
        }
        return;
      }
      if (k === "v" || k === "V") {
        setUiHidden(true);
        return;
      }
      if (k === "Enter" || k === " ") {
        if (Dlg.active) {
          e.preventDefault();
          advance(false);
        } else if (S.phase === "next") {
          e.preventDefault();
          goNext();
        }
        return;
      }
      if (S.phase === "cosplay" || S.phase === "compliment" || S.phase === "finale") {
        let i = -1;
        if (/^[1-5]$/.test(k)) i = Number(k) - 1;
        else if (/^[a-eA-E]$/.test(k)) i = k.toUpperCase().charCodeAt(0) - 65;
        const btns = el.choices.querySelectorAll(".choice");
        if (i >= 0 && btns[i]) btns[i].click();
        else if ((k === "h" || k === "H") && !el.btnHint.hidden) useHint();
      }
    });

    showTitle();
  }

  init();
})();
